from django.urls import path
from . import views

urlpatterns = [
    path('', views.product_list, name='product_list'),  # URL pattern for listing products
    path('<int:pk>/', views.ProductView.as_view(), name='product_detail'),  # URL pattern for product details
    path('add_to_cart/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/', views.view_cart, name='view_cart'),
    path('remove_from_cart/<int:product_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('save_shipping_details/', views.shipping_details, name='save_shipping_details'),
    path('payment/', views.payment, name='payment'),
    path('order_confirmation/', views.confirm, name='confirm'),
    path('my_orders',views.my_orders,name='my_orders'),
    path('adminproducts/', views.aproduct_list, name='aproduct_list'),
    
]
