
# views.py
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from .models import *
from django.views import generic

cart_items=[]
def product_list(request):
    products = Product.objects.filter(available=True)
    return render(request, 'product.html', {'products': products})

def aproduct_list(request):
    products = Product.objects.filter(available=True)
    return render(request, 'aproduct.html', {'products': products})

class ProductView(generic.DetailView):
    model=Product
    template_name='product_detail.html'
    template_object_name='product'

def add_to_cart(request, product_id):
    if request.method == 'POST':
        # Ensure the user is authenticated
        if not request.user.is_authenticated:
            return redirect('login')  # Redirect to login if user is not authenticated

        # Get the product
        product = get_object_or_404(Product, pk=product_id)

        # Add the product to the cart
        cart_item, created = Cart.objects.get_or_create(user=request.user, product=product)

        # Redirect back to the product list or a specific page
        return redirect('view_cart')
    else:
        return HttpResponse("Invalid request", status=400)
    

def view_cart(request):
    # Ensure the user is authenticated
    if not request.user.is_authenticated:
        return redirect('login')  # Redirect to login if user is not authenticated

    # Get cart items for the logged-in user
    cart_items = Cart.objects.filter(user=request.user)

    # Render the cart template with cart items
    return render(request, 'cart.html', {'cart_items': cart_items})

def remove_from_cart(request, product_id):
    if request.method == 'POST':
        # Ensure the user is authenticated
        if not request.user.is_authenticated:
            return redirect('login')  # Redirect to login if user is not authenticated

        # Get the product
        product = get_object_or_404(Product, pk=product_id)

        # Try to get the cart item
        try:
            cart_item = Cart.objects.get(user=request.user, product=product)
            cart_item.delete()  # Remove the item from the cart
        except Cart.DoesNotExist:
            return HttpResponse("Item not found in cart", status=404)  # Optional: Handle item not found

        # Redirect to the cart page or any other page
        return redirect('view_cart')  # Replace 'view_cart' with the name of your cart page URL pattern
    else:
        return HttpResponse("Invalid request", status=400)
    

def shipping_details(request):
    if request.method == 'POST':
        print("post method")
        name = request.POST['name']
        address = request.POST['address']
        city = request.POST['city']
        state = request.POST['state']
        zip_code = request.POST['zip']
        

        ShippingDetails.objects.create(
            user=request.user,
            name=name,
            address=address,
            city=city,
            state=state,
            zip_code=zip_code,
           
        )
        print('Added...')
        return redirect('payment')  # Replace with your confirmation view

    return render(request, 'shipping.html')

def payment(request):
    return redirect('confirm')

from django.core.exceptions import ObjectDoesNotExist
def confirm(request):
    # Ensure the user is authenticated
    if not request.user.is_authenticated:
        return redirect('login')

    try:
        # Fetch the latest shipping details for the user
        shipping_details = ShippingDetails.objects.filter(user=request.user).latest('created_at')
    except ObjectDoesNotExist:
        # Handle the case where no shipping details are found
        return redirect('shipping_details')  # Redirect to the shipping details page or an error page

    # Get the products from the cart
    cart_items = Cart.objects.filter(user=request.user)
    products = [item.product for item in cart_items]

    # Create a new order
    order = Order.objects.create(
        user=request.user,
        shipping_details=shipping_details
    )
    order.products.set(products)
    order.save()

    # Clear the cart
    cart_items.delete()

    # Redirect to an order confirmation page or similar
    return render(request, 'confirmation.html')  # Ensure 'confirmation.html' template exists

def my_orders(request):
    if not request.user.is_authenticated:
        return HttpResponse("Unauthorized Request")
    user = request.user
    orders = Order.objects.filter(user=user).order_by('-created_at')
    print(orders)
    return render(request,'my_orders.html',{'orders':orders})

def adminpage(request):
    orders=Order.objects.all()
    return render(request,'adminpage.html',{'orders':orders})


from .foms import ProductForm
from .models import Product
def addproduct(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)  # Include request.FILES for image uploads
        if form.is_valid():
            form.save()
            return redirect('product_list')  # Redirect to the product list or a success page
    else:
        form = ProductForm()

    return render(request, 'add_product.html', {'form': form})