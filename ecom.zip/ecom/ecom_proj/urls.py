"""
URL configuration for ecom_proj project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from accounts.views import *
from product import views
from .settings import *
from django.conf.urls.static import static
from ecom_proj import settings
urlpatterns = [
    #path('admin/', admin.site.urls),
     path('products/', include('product.urls')),
     path('login/',login_view,name='login'),
     path('register/', register,name='register'),
     path('logout/',custom_logout,name='logout'),
     path('adminpage/',views.adminpage,name='admin_page'),
     path('addproduct/',views.addproduct,name='add_product'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)