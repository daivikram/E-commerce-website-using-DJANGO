
# Create your views here.
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm

from product.models import Order
from .forms import CustomAuthenticationForm

def login_view(request):
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                # Store user data in the session
                request.session['username'] = username
                request.session['user_id'] = user.id
                if username=='admin':
                    return redirect('admin_page')
                return redirect('product_list')  # Redirect to your dashboard
    else:
        form = CustomAuthenticationForm()

    return render(request, 'login.html', {'form': form})

from .forms import RegistrationForm

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # Automatically log in the user after registration
            return redirect('product_list')  # Redirect to the dashboard or another page
    else:
        form = RegistrationForm()
    return render(request, 'register.html', {'form': form})

from django.contrib.auth import logout

def custom_logout(request):
    logout(request)
    
    return redirect('login')


def all_orders(request):
    if request.user.is_authenticated and request.user.username == 'admin':
        # Fetch all orders
        orders = Order.objects.all().order_by('-created_at')  # Assuming you have a 'created_at' field

        # Pass orders to the template
        return render(request, 'admin_orders.html', {'orders': orders})
    else:
        return HttpResponse('<h1>Unauthorized Access</h1>',status=403)