from django.urls import path
from . import views
from .views import order_confirmation, place_order, product_detail, product_list



urlpatterns = [
      path('', product_list, name='product_list'),
    path('category/<int:category_id>/', product_list, name='product_list_by_category'),
     path('product/<int:pk>/', product_detail, name='product_detail'),
    path('add_to_cart/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('view_cart/', views.view_cart, name='view_cart'),
     path('update_cart/', views.update_cart, name='update_cart'),
      path('place_order/', place_order, name='place_order'),
    path('order_confirmation/', order_confirmation, name='order_confirmation'),
   
]
