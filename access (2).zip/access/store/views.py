import json
from django.shortcuts import render, get_object_or_404
from .models import Product,Category
from django.shortcuts import render, redirect
from django.http import JsonResponse
from .cart import Cart


def product_list(request):
    categories = Category.objects.all()
    category_id = request.GET.get('category_id')  # Get the category_id from the query parameters

    if category_id:
        products = Product.objects.filter(category_id=category_id)
    else:
        products = Product.objects.all()

    context = {
        'products': products,
        'categories': categories,
        'selected_category': category_id  # Pass the selected category to the template
    }

    return render(request, 'product_list.html', context)
def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request, 'product_detail.html', {'product': product})



def add_to_cart(request, product_id):
    cart = Cart(request)
    product = get_object_or_404(Product, id=product_id)
    cart.add(product_id=product.id)
    return redirect('view_cart')
def view_cart(request):
    cart = Cart(request)
    cart_items = list(cart)
    total_price = cart.get_total_price()  # Ensure you have this method in your Cart class
    context = {
        'cart_items': cart_items,
        'total_price': total_price,
        'show_remove_button': False  # Set this to False if you don't want the remove button
    }
    return render(request, 'view_cart.html', context)
def update_cart(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        product_id = data.get('product_id')
        quantity = data.get('quantity')

        cart = Cart(request)
        if quantity > 0:
            cart.update(product_id, quantity)
        elif quantity == 0:
            cart.remove(product_id)
        
        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'error'})



def cart_actions(request):
    if request.method == 'POST':
        action = request.POST.get('action')
        product_id = request.POST.get('product_id')
        quantity = request.POST.get('quantity', 1)
        
        cart = Cart(request)
        
        if action == 'add':
            cart.add(product_id, int(quantity))
            return JsonResponse({'status': 'Product added to cart'})
        
        elif action == 'update':
            cart.update(product_id, int(quantity))
            return JsonResponse({'status': 'Cart updated'})
        
        elif action == 'remove':
            cart.remove(product_id)
            return JsonResponse({'status': 'Product removed from cart'})
    
    elif request.method == 'GET':
        cart = Cart(request)
        return render(request, 'cart.html', {'cart': cart})
    
    return JsonResponse({'status': 'Invalid request'}, status=400)

def place_order(request):
    cart = Cart(request)
    if len(cart) == 0:
        return redirect('view_cart')

    cart.clear()  # Clear the cart after placing the order

    return redirect('order_confirmation')

def order_confirmation(request):
    return render(request, 'order_confirmation.html')